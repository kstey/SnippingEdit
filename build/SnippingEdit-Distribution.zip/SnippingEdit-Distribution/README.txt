SnippingEdit for macOS
======================

A professional screenshot and annotation tool with instant selection,
resize handles, and smart capture features.

QUICK START
-----------
1. Double-click SnippingEdit.app to launch
2. Minimize the app to dock
3. Copy any image to clipboard (e.g., Cmd+Shift+4 + Control)
4. Click dock icon to open and edit the image

IF APP WON'T OPEN ("damaged" error)
------------------------------------
This is a macOS security feature for unsigned apps.

Quick Fix:
  1. Open Terminal (Applications > Utilities > Terminal)
  2. Type: cd
  3. Drag this folder into Terminal window
  4. Press Enter
  5. Type: ./FIX_IF_DAMAGED.sh
  6. Press Enter
  7. Try opening the app again

Alternative Fix:
  - Right-click SnippingEdit.app
  - Select "Open"
  - Click "Open" in the dialog

FEATURES
--------
• Automatic clipboard monitoring
• Image editing and annotation
• 8-color drawing palette
• One-click clipboard copy
• Keyboard shortcuts (Delete to undo, Cmd+R to clear)

REQUIREMENTS
------------
• macOS 14.0 or later
• No special permissions required (clipboard access only)

SUPPORT
-------
For issues or questions, see GATEKEEPER_FIX.md
or visit the project repository.

Enjoy! 🎉
